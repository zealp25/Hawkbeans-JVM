package java.io;

public class UnsupportedEncodingException extends IOException {
    public UnsupportedEncodingException() {
        super();
    }
    
    public UnsupportedEncodingException(String s) {
        super(s);
    }
}
