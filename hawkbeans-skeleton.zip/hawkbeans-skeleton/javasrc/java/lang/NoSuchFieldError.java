package java.lang;

public class NoSuchFieldError extends Error
{
	public NoSuchFieldError()
	{
		super();
	}
}
