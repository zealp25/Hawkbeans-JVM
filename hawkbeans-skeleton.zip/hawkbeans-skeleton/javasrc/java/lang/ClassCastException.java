package java.lang;

public class ClassCastException extends RuntimeException
{
}
