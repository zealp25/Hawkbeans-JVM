package java.lang;

public class AssertionError extends Error
{
	public AssertionError()
	{
		super();
	}
}
