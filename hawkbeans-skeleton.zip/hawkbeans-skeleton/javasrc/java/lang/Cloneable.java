package java.lang;

/**
 * This interface is not functional. It's here
 * to satisfy jikes.
 */
public interface Cloneable
{
	//just an indicator interface
}
