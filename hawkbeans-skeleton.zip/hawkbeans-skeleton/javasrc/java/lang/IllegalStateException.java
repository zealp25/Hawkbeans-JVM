package java.lang;

public class IllegalStateException extends RuntimeException
{
}
