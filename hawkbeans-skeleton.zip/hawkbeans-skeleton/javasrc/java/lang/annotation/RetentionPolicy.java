package java.lang.annotation;

public enum RetentionPolicy
{
    SOURCE,
    CLASS,
    RUNTIME,
}
