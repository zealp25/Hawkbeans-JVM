

public class TestArrayAssign {

	public static void main (String[] args) {
		String x = new String("hi there");
		System.out.println(x);
	}
}
