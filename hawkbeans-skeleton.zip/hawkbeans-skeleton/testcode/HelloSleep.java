
import java.lang.Thread;

public class HelloSleep {

	public static void main (String[] args) 
		throws InterruptedException {
		System.out.println("Hello, New World!");
		Thread.sleep(1000);
	} 
}
